#version 330 core
out vec4 FragColor;

struct Material {
    vec3 ambient;
    vec3 diffuse;
    float specular;
    float shininess;
}; 
  

in vec3 Normal;  
in vec3 FragPos;
in vec2 Texcoord;  
  
uniform vec3 lightPos[4]; 
uniform vec3 viewPos; 
uniform vec3 lightColor;
uniform vec3 objectColor;
uniform Material material;

uniform sampler2D texture1;

vec3 doLighting(vec3 lightPos, vec3 normal, vec3 amb);

void main()
{
    vec3 n = Normal;
    if(dot(normalize(viewPos - FragPos), normalize(n)) < 0.0f)
	n = -n;
    // ambient
    vec3 ambient = material.ambient * lightColor;
    
  	vec3 result = doLighting(lightPos[0], n, ambient);
	result += doLighting(lightPos[1], n, ambient);
	result += doLighting(lightPos[2], n, ambient);
	result += doLighting(lightPos[3], n, ambient);
   
    FragColor = vec4(result, 1.0);
} 

vec3 doLighting(vec3 lightPos, vec3 normal, vec3 amb){
	 // diffuse 
    vec3 norm = normalize(normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(norm, lightDir), 0.0f);
    vec3 diffuse = lightColor * (diff * material.diffuse);
    
    // specular
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 reflectDir = reflect(-lightDir, norm);  
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
    vec3 specular = lightColor * (spec * material.specular);  
    
    vec3 baseColor = texture(texture1, Texcoord).rgb;    
    return (amb + diffuse + specular) * baseColor;
}