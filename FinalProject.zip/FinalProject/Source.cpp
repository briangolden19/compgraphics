#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"      // Image loading Utility functions

using namespace std; // Uses the standard namespace
// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "Camera.h"
#include "shader.h"

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
	const char* const WINDOW_TITLE = "Brian Golden Final Project"; // Holds the title for the GL window

	//Variables to hold the initalization size of the window
	const int WINDOW_HEIGHT = 600;
	const int WINDOW_WIDTH = 800;

	struct Material {
		glm::vec3 ambient;
		glm::vec3 diffuse;
		float specular;
		float shininess;
	};

	struct MyMeshes {
		unsigned int vertexBuffer;
		unsigned int texcoordBuffer;
		unsigned int normalsBuffer;
		unsigned int VAO;
		std::vector<glm::vec3> vertices;
		std::vector<glm::vec2> texcoords;
		std::vector<glm::vec3> normals;
		void upload(bool genNorms) {
			
			if (genNorms) {
				generateFlatNorms();
			}
			glGenVertexArrays(1, &VAO);
			glGenBuffers(1, &vertexBuffer);
			glGenBuffers(1, &texcoordBuffer);
			glGenBuffers(1, &normalsBuffer);
			glBindVertexArray(VAO);
			//upload vertex buffer
			glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
			glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(glm::vec3), vertices.data(), GL_STATIC_DRAW);
			//upload texcoord buffer
			glBindBuffer(GL_ARRAY_BUFFER, texcoordBuffer);
			glBufferData(GL_ARRAY_BUFFER, texcoords.size() * sizeof(glm::vec2), texcoords.data(), GL_STATIC_DRAW);
			//upload normals buffer
			glBindBuffer(GL_ARRAY_BUFFER, normalsBuffer);
			glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(glm::vec3), normals.data(), GL_STATIC_DRAW);

			// position attribute
			glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
			glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
			glEnableVertexAttribArray(0);
			// texture coord attribute
			glBindBuffer(GL_ARRAY_BUFFER, texcoordBuffer);
			glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
			glEnableVertexAttribArray(1);
			//normals attribute
			glBindBuffer(GL_ARRAY_BUFFER, normalsBuffer);
			glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
			glEnableVertexAttribArray(2);
		}
		void cleanUp() {
			// optional: de-allocate all resources once they've outlived their purpose:
			// ------------------------------------------------------------------------
			glDeleteVertexArrays(1, &VAO);
			glDeleteBuffers(1, &vertexBuffer);
			glDeleteBuffers(1, &texcoordBuffer);
			glDeleteBuffers(1, &normalsBuffer);
		}
		void draw(glm::mat4 model, Shader currentShader, unsigned int texture) {
			// render boxes
			glBindVertexArray(VAO);
			// calculate the model matrix for each object and pass it to shader before drawing

			currentShader.setMat4("model", model);

			// bind textures on corresponding texture units
			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, texture);

			glDrawArrays(GL_TRIANGLES, 0, vertices.size());
		}
		void generateFlatNorms()
		{
			normals.resize(vertices.size());
			for (size_t i = 0; i < vertices.size() / 3; i++)
			{
				glm::vec3 p0 = vertices[i * 3 + 0];
				glm::vec3 p1 = vertices[i * 3 + 1];
				glm::vec3 p2 = vertices[i * 3 + 2];

				glm::vec3 e0 = glm::normalize(p1 - p0);
				glm::vec3 e1 = glm::normalize(p2 - p0);

				glm::vec3 n = glm::cross(e0, e1);

				normals[i * 3 + 0] = n;
				normals[i * 3 + 1] = n;
				normals[i * 3 + 2] = n;
			}
		}
	};

	struct Cylinder {
		const float numSlices = 32.0f;
		const float PI = 3.1415926f;
		float height, radius;
		vector<glm::vec2> xzs;
		vector<glm::vec3> verticiesBase;
		vector<glm::vec3> verticiesSides;
		vector<glm::vec3> normsBase;
		vector<glm::vec3> normsSides;
		vector<glm::vec2> texCoordsBase;
		vector<glm::vec2> texCoordsSides;

		void setSize(float h, float r)
		{
			height = h;
			radius = r;
		}

		void buildCylinder() {
			generateXZs();
			generateCylBase(true);
			generateCylBase(false);
			generateSides();
		}

		void generateXZs() {
			float sectorStep = 2 * PI / numSlices;
			float sectorAngle;

			for (int i = 0; i < numSlices; i++) {
				sectorAngle = i * sectorStep;
				glm::vec2 temp = glm::vec2(cos(sectorAngle) * radius, sin(sectorAngle) * radius);
				xzs.push_back(temp);
			}
		}

		void generateCylBase(bool bottom) {
			int i;
			float yC;
			if (bottom) {
				yC = 0;
			}
			else {
				yC = height;
			}
			for (i = 0; i < numSlices - 1; i++) {
				//creating tris 
				glm::vec3 v1 = glm::vec3(xzs.at(i).x, yC, xzs.at(i).y);
				glm::vec3 v2 = glm::vec3(0.0f, yC, 0.0f);
				glm::vec3 v3 = glm::vec3(xzs.at(i + 1).x, yC, xzs.at(i + 1).y);
				verticiesBase.push_back(v1);
				verticiesBase.push_back(v2);
				verticiesBase.push_back(v3);
				if (bottom) {
					glm::vec3 n1 = glm::vec3(0, -1, 0);
					glm::vec3 n2 = glm::vec3(0, -1, 0);
					glm::vec3 n3 = glm::vec3(0, -1, 0);
					normsBase.push_back(n1);
					normsBase.push_back(n2);
					normsBase.push_back(n3);
				}
				else {
					glm::vec3 n1 = glm::vec3(0, 1, 0);
					glm::vec3 n2 = glm::vec3(0, 1, 0);
					glm::vec3 n3 = glm::vec3(0, 1, 0);
					normsBase.push_back(n1);
					normsBase.push_back(n2);
					normsBase.push_back(n3);
				}
				glm::vec2 tex1 = glm::vec2(-xzs.at(i).x * 0.5f + 0.5f, -xzs.at(i).y * 0.5f + 0.5f);
				glm::vec2 tex2 = glm::vec2(0.0f, 0.0f);
				glm::vec2 tex3 = glm::vec2(-xzs.at(i + 1).x * 0.5f + 0.5f, -xzs.at(i + 1).y * 0.5f + 0.5f);
				texCoordsBase.push_back(tex1);
				texCoordsBase.push_back(tex2);
				texCoordsBase.push_back(tex3);
				
			}
			
			glm::vec3 v1 = glm::vec3(xzs.at(i).x, yC, xzs.at(i).y);
			glm::vec3 v2 = glm::vec3(0.0f, yC, 0.0f);
			glm::vec3 v3 = glm::vec3(xzs.at(0).x, yC, xzs.at(0).y);
			verticiesBase.push_back(v1);
			verticiesBase.push_back(v2);
			verticiesBase.push_back(v3);
			if (bottom) {
				glm::vec3 n1 = glm::vec3(0, -1, 0);
				glm::vec3 n2 = glm::vec3(0, -1, 0);
				glm::vec3 n3 = glm::vec3(0, -1, 0);
				normsBase.push_back(n1);
				normsBase.push_back(n2);
				normsBase.push_back(n3);
			}
			else {
				glm::vec3 n1 = glm::vec3(0, 1, 0);
				glm::vec3 n2 = glm::vec3(0, 1, 0);
				glm::vec3 n3 = glm::vec3(0, 1, 0);
				normsBase.push_back(n1);
				normsBase.push_back(n2);
				normsBase.push_back(n3);
			}
			glm::vec2 tex1 = glm::vec2(-xzs.at(i).x * 0.5f + 0.5f, -xzs.at(i).y * 0.5f + 0.5f);
			glm::vec2 tex2 = glm::vec2(0.0f, 0.0f);
			glm::vec2 tex3 = glm::vec2(-xzs.at(0).x * 0.5f + 0.5f, -xzs.at(0).y * 0.5f + 0.5f);
			texCoordsBase.push_back(tex1);
			texCoordsBase.push_back(tex2);
			texCoordsBase.push_back(tex3);
		}

		//Generate the sides of the cylinder
		void generateSides() {
			int i = 0;
			float normXJump = 1.0f / numSlices;

			float fstNorm1 = 1.0f - normXJump;
			float fstNorm2 = 1.0f;

			glm::vec3 fv1 = glm::vec3(xzs.at(i).x, 0.0f, xzs.at(i).y); // right bottom
			glm::vec2 ftex1 = glm::vec2(fstNorm1, 0.0f);
			
			glm::vec3 fv2 = glm::vec3(xzs.at(i + 1).x, 0.0f, xzs.at(i + 1).y); // left bottom
			glm::vec2 ftex2 = glm::vec2(fstNorm2, 0.0f);
		
			glm::vec3 fv3 = glm::vec3(xzs.at(i + 1).x, height, xzs.at(i + 1).y); // left top
			glm::vec2 ftex3 = glm::vec2(fstNorm2, 1.0f);
			
			glm::vec3 fv4 = glm::vec3(xzs.at(i).x, 0.0f, xzs.at(i).y); // right bottom
			glm::vec2 ftex4 = glm::vec2(fstNorm1, 0.0f);
			
			glm::vec3 fv5 = glm::vec3(xzs.at(i).x, height, xzs.at(i).y); //right top
			glm::vec2 ftex5 = glm::vec2(fstNorm1, 1.0f);

			glm::vec3 fv6 = glm::vec3(xzs.at(i + 1).x, height, xzs.at(i + 1).y); //left top
			glm::vec2 ftex6 = glm::vec2(fstNorm2, 1.0f);


			verticiesSides.push_back(fv1);
			texCoordsSides.push_back(ftex1);

			verticiesSides.push_back(fv2);
			texCoordsSides.push_back(ftex2);

			verticiesSides.push_back(fv3);
			texCoordsSides.push_back(ftex3);

			verticiesSides.push_back(fv4);
			texCoordsSides.push_back(ftex4);

			verticiesSides.push_back(fv5);
			texCoordsSides.push_back(ftex5);

			verticiesSides.push_back(fv6);
			texCoordsSides.push_back(ftex6);

			glm::vec3 fn1 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 fn2 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 fn3 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 fn4 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 fn5 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 fn6 = glm::vec3(0.5f, 0.0f, 0.5f);
			normsSides.push_back(fn1);
			normsSides.push_back(fn2);
			normsSides.push_back(fn3);
			normsSides.push_back(fn4);
			normsSides.push_back(fn5);
			normsSides.push_back(fn6);


			for (i = 1; i < numSlices - 1; i++) {
				float xNormPos1 = ((float)(i - 1) * normXJump);
				float xNormPos2 = (float((i)) * normXJump);
				//float xNormPos1 = 0;
				//float xNormPos2 = 0;

				glm::vec3 v1 = glm::vec3(xzs.at(i).x, 0.0f, xzs.at(i).y); // right bottom
				glm::vec2 tex1 = glm::vec2(xNormPos1, 0.0f);
				//cout << "V1 XYZ: " << v1.x << " " << v1.y << " " << v1.z << endl;
				 
				glm::vec3 v2 = glm::vec3(xzs.at(i + 1).x, 0.0f, xzs.at(i + 1).y); // left bottom
				glm::vec2 tex2 = glm::vec2(xNormPos2, 0.0f);
				//cout << "V2 XYZ: " << v2.x << " " << v2.y << " " << v2.z << endl;

				glm::vec3 v3 = glm::vec3(xzs.at(i + 1).x, height, xzs.at(i + 1).y); // left top
				glm::vec2 tex3 = glm::vec2(xNormPos2, 1.0f);
				//cout << "V3 XYZ: " << v3.x << " " << v3.y << " " << v3.z << endl;

				glm::vec3 v4 = glm::vec3(xzs.at(i).x, 0.0f, xzs.at(i).y); // right bottom
				glm::vec2 tex4 = glm::vec2(xNormPos1, 0.0f);
				//cout << "V4 XYZ: " << v4.x << " " << v4.y << " " << v4.z << endl;

				glm::vec3 v5 = glm::vec3(xzs.at(i).x, height, xzs.at(i).y); //right top
				glm::vec2 tex5 = glm::vec2(xNormPos1, 1.0f);
				//cout << "V5 XYZ: " << v5.x << " " << v5.y << " " << v5.z << endl;

				glm::vec3 v6 = glm::vec3(xzs.at(i + 1).x, height, xzs.at(i + 1).y); //left top
				glm::vec2 tex6 = glm::vec2(xNormPos2, 1.0f);
				//cout << "V6 XYZ: " << v6.x << " " << v6.y << " " << v6.z << endl;


				verticiesSides.push_back(v1);
				texCoordsSides.push_back(tex1);

				verticiesSides.push_back(v2);
				texCoordsSides.push_back(tex2);

				verticiesSides.push_back(v3);
				texCoordsSides.push_back(tex3);

				verticiesSides.push_back(v4);
				texCoordsSides.push_back(tex4);

				verticiesSides.push_back(v5);
				texCoordsSides.push_back(tex5);

				verticiesSides.push_back(v6);
				texCoordsSides.push_back(tex6);

				glm::vec3 n1 = glm::vec3(0.5f, 0.0f, 0.5f);
				glm::vec3 n2 = glm::vec3(0.5f, 0.0f, 0.5f);
				glm::vec3 n3 = glm::vec3(0.5f, 0.0f, 0.5f);
				glm::vec3 n4 = glm::vec3(0.5f, 0.0f, 0.5f);
				glm::vec3 n5 = glm::vec3(0.5f, 0.0f, 0.5f);
				glm::vec3 n6 = glm::vec3(0.5f, 0.0f, 0.5f);
				normsSides.push_back(n1);
				normsSides.push_back(n2);
				normsSides.push_back(n3);
				normsSides.push_back(n4);
				normsSides.push_back(n5);
				normsSides.push_back(n6);
				
			}
			//For Final Slice
			i = numSlices - 1;
			glm::vec3 v1 = glm::vec3(xzs.at(i).x, 0.0f, xzs.at(i).y); // left bottom
			glm::vec3 v2 = glm::vec3(xzs.at(0).x, 0.0f, xzs.at(0).y); // right bottom
			glm::vec3 v3 = glm::vec3(xzs.at(0).x, height, xzs.at(0).y); // right top
			glm::vec3 v4 = glm::vec3(xzs.at(i).x, 0.0f, xzs.at(i).y); // left bottom
			glm::vec3 v5 = glm::vec3(xzs.at(i).x, height, xzs.at(i).y); //left top
			glm::vec3 v6 = glm::vec3(xzs.at(0).x, height, xzs.at(0).y); //right top
			verticiesSides.push_back(v1);
			verticiesSides.push_back(v2);
			verticiesSides.push_back(v3);
			verticiesSides.push_back(v4);
			verticiesSides.push_back(v5);
			verticiesSides.push_back(v6);

			// texCoords
			float xNormPos1 = (float)(i - 1)* normXJump;
			float xNormPos2 = 1;
			glm::vec2 tex1 = glm::vec2(xNormPos1, 0.0f);
			glm::vec2 tex2 = glm::vec2(xNormPos2, 0.0f);
			glm::vec2 tex3 = glm::vec2(xNormPos2, 1.0f);
			glm::vec2 tex4 = glm::vec2(xNormPos1, 0.0f);
			glm::vec2 tex5 = glm::vec2(xNormPos1, 1.0f);
			glm::vec2 tex6 = glm::vec2(xNormPos2, 1.0f);
			texCoordsSides.push_back(tex1);
			texCoordsSides.push_back(tex2);
			texCoordsSides.push_back(tex3);
			texCoordsSides.push_back(tex4);
			texCoordsSides.push_back(tex5);
			texCoordsSides.push_back(tex6);

			glm::vec3 n1 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 n2 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 n3 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 n4 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 n5 = glm::vec3(0.5f, 0.0f, 0.5f);
			glm::vec3 n6 = glm::vec3(0.5f, 0.0f, 0.5f);
			normsSides.push_back(n1);
			normsSides.push_back(n2);
			normsSides.push_back(n3);
			normsSides.push_back(n4);
			normsSides.push_back(n5);
			normsSides.push_back(n6);
		}

		vector<glm::vec3> getVerticiesBase() {
			return verticiesBase;
		}
		vector<glm::vec3> getVerticesSides() {
			return verticiesSides;
		}
		vector<glm::vec2> getTexCoordsBase() {
			return texCoordsBase;
		}
		vector<glm::vec2> getTexCoordsSides() {
			return texCoordsSides;
		}
		vector<glm::vec3> getNormsBase() {
			return normsBase;
		}

		vector<glm::vec3> getNormsSides() {
			return normsSides;
		}
	};


	//Mesh Party
	MyMeshes planeMesh; //plane 
	MyMeshes boxFrontBackMesh; //the honey stinger box
	MyMeshes boxSideMesh;
	MyMeshes topMesh; //top of the honey stinger
	MyMeshes pumpkinFace;
	MyMeshes pumpkinSides;
	MyMeshes lightBox;

	//Cylinders
	MyMeshes beanSidesMesh;
	MyMeshes beanTopMesh;
	MyMeshes loliStickSidesMesh;
	MyMeshes loliStickTopMesh;

	MyMeshes lolipopMesh1;
	MyMeshes lolipopMesh2;

	// Textures
	GLuint gBoxFrontBack; 
	GLuint gBoxSide;
	GLuint gBoxTop;
	GLuint gCounter;
	GLuint gBeanCanSides;
	GLuint gBeanCanTop;
	GLuint gLoliStick;
	GLuint gLoliProper;
	GLuint gPumpkinFace;
	GLuint gPumpkinSides;

	//Materials
	Material boxMat;
	Material counterMat;
	Material beanCanMat;
	Material lolipopMat;
	Material pumpkinMat;
	Material lightMat;

	// Main GLFW window
	GLFWwindow* gWindow = nullptr;

	// camera
	Camera camera(glm::vec3(0.0f, 1.0f, 10.0f)); // start camera back 10 in the z and up one to center the scene
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// timing
	float gDeltaTime = 0.0f; // time between current frame and last frame
	float gLastFrame = 0.0f;

	//Toggle between ortho and perspective
	bool perspective = true;
	bool pPressed = false; // helps with not flickering when switching perspective
}



bool UInitialize(int, char* [], GLFWwindow** window); //initalizes the window
void UResizeWindow(GLFWwindow* window, int width, int height); //handles window resize
void UProcessInput(GLFWwindow* window); // Processes user input
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void URender(Shader ourShader); //render each frame
void loadTexture(const char* filename, GLuint& texture, bool flip);
void setupVertices();
void setupTextCoords();
void setupMaterials();
void setupCylinders();
void loadTextures();
void uploadAll();
void cleanupAll();


//main function
int main(int argc, char* argv[]) {

	if (!UInitialize(argc, argv, &gWindow)) //attempt to init the window
		return EXIT_FAILURE;
	Shader ourShader("shaders/vert.vs", "shaders/frag.fs");
	loadTextures();
	setupVertices();
	setupTextCoords();
	setupCylinders();

	setupMaterials();

	uploadAll();

	//render loop
	while (!glfwWindowShouldClose(gWindow)) {

		// per-frame timing
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrame;
		gLastFrame = currentFrame;

		UProcessInput(gWindow); //process user input

		URender(ourShader);// render the frame

		glfwPollEvents(); //checks for IO events like keyboard and mouse input
	}

	cleanupAll();
	
	exit(EXIT_SUCCESS);
}

bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
	// GLFW: initialize and configure (specify desired OpenGL version)
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// GLFW: window creation
	* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (*window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);
	glfwSetCursorPosCallback(*window, UMousePositionCallback);
	glfwSetScrollCallback(*window, UMouseScrollCallback);
	glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// GLEW: initialize
	// Note: if using GLEW version 1.13 or earlier
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();

	if (GLEW_OK != GlewInitResult)
	{
		std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
		return false;
	}

	// Displays GPU OpenGL version
	cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

	return true;
}

// process all Key input
void UProcessInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) // W to move forward
		camera.ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)  // S to move back
		camera.ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) // A to move left
		camera.ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)  // D to move right
		camera.ProcessKeyboard(RIGHT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)  // Q to go up
		camera.ProcessKeyboard(UP, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)  // E to go down
		camera.ProcessKeyboard(DOWN, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS && !pPressed) { // makes sure that p is pressed but wasnt already pressed
			perspective = !perspective;
			pPressed = true; // since p is pressed we set this to true
	}
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_RELEASE && pPressed) { // if p is released and p pressed was true
		pPressed = false; // set p pressed to false. This all helps with flickering perspective changes
	}
	
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (gFirstMouse)
	{
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

	gLastX = xpos;
	gLastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	camera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	switch (button)
	{
	case GLFW_MOUSE_BUTTON_LEFT:
	{
		if (action == GLFW_PRESS) {
			cout << "Left mouse button pressed" << endl;
			//cout << "X: " << camera.getWorldPos().x << "\nY: " << camera.getWorldPos().y << "\nZ: " << camera.getWorldPos().z << endl;
		}
		else
			cout << "Left mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_MIDDLE:
	{
		if (action == GLFW_PRESS)
			cout << "Middle mouse button pressed" << endl;
		else
			cout << "Middle mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_RIGHT:
	{
		if (action == GLFW_PRESS)
			cout << "Right mouse button pressed" << endl;
		else
			cout << "Right mouse button released" << endl;
	}
	break;

	default:
		cout << "Unhandled mouse button event" << endl;
		break;
	}
}

//Load all my textures 
void loadTextures() {
	loadTexture("images/honeeyboxFront.jpg", gBoxFrontBack, false);
	loadTexture("images/honeyBoxTop.jpg", gBoxTop, false);
	loadTexture("images/honeyboxSide.jpg", gBoxSide, false);
	loadTexture("images/countertops.jpg", gCounter, false);
	loadTexture("images/beans.jpg", gBeanCanSides, false);
	loadTexture("images/beansTop.jpg", gBeanCanTop, false);
	loadTexture("images/lolipopStick.jpg", gLoliStick, false);
	loadTexture("images/lolipopProper.jpg", gLoliProper, false);
	loadTexture("images/pumpkinFace.jpg", gPumpkinFace, false);
	loadTexture("images/orangeSides.jpg", gPumpkinSides, false);
}

// Called to render a frame
void URender(Shader ourShader)
{
	// Enable z-depth
	glEnable(GL_DEPTH_TEST);

	// Clear the frame and z buffers
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	ourShader.use();

	glm::mat4 model;
	glm::mat4 projection;

	if (perspective)
	{
		// pass projection matrix to shader (note that in this case it could change every frame)
		projection = glm::perspective(glm::radians(camera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
	}
	else {
		float scale = 100;
		projection = glm::ortho(-((float)WINDOW_WIDTH / scale), (float)WINDOW_WIDTH / scale, -(float)WINDOW_HEIGHT / scale, ((float)WINDOW_HEIGHT / scale), -50.0f, 50.0f);
	}

	ourShader.setMat4("projection", projection);

	glm::vec3 lightPos[] = {
		glm::vec3(-5.0,5.0f,5.0f),
		glm::vec3(5.0,5.0f,5.0f),
		glm::vec3(5.0,5.0f,-5.0f),
		glm::vec3(-5.0,5.0f,-5.0f)
	};
	
	glm::vec3 lightColor = glm::vec3(0.9f, 0.5f, 0.3f); //This value changes the color of the light
	//glm::vec3 lightColor = glm::vec3(0.7f, 0.7f, 0.7f);
	// camera/view transformation
	glm::mat4 view = camera.GetViewMatrix();
	ourShader.setMat4("view", view);

	//Setup Lighting 
	ourShader.setVec3("lightPos[0]", lightPos[0]);
	ourShader.setVec3("lightPos[1]", lightPos[1]);
	ourShader.setVec3("lightPos[2]", lightPos[2]);
	ourShader.setVec3("lightPos[3]", lightPos[3]);

	
	ourShader.setVec3("viewPos", camera.Position);

	ourShader.setVec3("lightColor", lightColor);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
	model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));

	//Rotations and Scaling 
	glm::mat4 boxRotation = glm::rotate(glm::radians(30.0f), glm::vec3(0.0f, 1.0f, 0.0f)); //rotates the box by 30 degrees in the Y

	glm::mat4 planeScaling = glm::scale(glm::vec3(1.5f, 0.25f, 1.5f)); //Used to scale the plane by 2

	glm::mat4 beanRotation = glm::rotate(glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // flip the can for reasons
	beanRotation = beanRotation * glm::rotate(glm::radians(-75.0f), glm::vec3(0.0f, 1.0f, 0.0f)); // rotate along the Y for front of label displaying front

	glm::mat4 loliRotation = glm::rotate(glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f)); // rotate 90 degress in the z
	loliRotation = loliRotation * glm::rotate(glm::radians(-30.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // then rotate -30 in the x
	

	//Draw each object
	ourShader.setVec3("material.ambient", counterMat.ambient);
	ourShader.setVec3("material.diffuse", counterMat.diffuse);
	ourShader.setFloat("material.specular", counterMat.specular);
	ourShader.setFloat("material.shininess", counterMat.shininess);
	planeMesh.draw(glm::translate(model, glm::vec3(0.5f, -0.25f, 0.0f)) * planeScaling, ourShader, gCounter); //Draw the plane

	ourShader.setVec3("material.ambient", boxMat.ambient);
	ourShader.setVec3("material.diffuse", boxMat.diffuse);
	ourShader.setFloat("material.specular", boxMat.specular);
	ourShader.setFloat("material.shininess", boxMat.shininess);
	boxFrontBackMesh.draw(glm::translate(model, glm::vec3(0.0f, -0.22f, 0.0f)) * boxRotation, ourShader, gBoxFrontBack);
	boxSideMesh.draw(glm::translate(model, glm::vec3(0.0f, -0.22f, 0.0f)) * boxRotation, ourShader, gBoxSide);
	topMesh.draw(glm::translate(model, glm::vec3(0.0f, 1.28f, 0.0f)) * boxRotation, ourShader, gBoxTop);
	
	ourShader.setVec3("material.ambient", beanCanMat.ambient);
	ourShader.setVec3("material.diffuse", beanCanMat.diffuse);
	ourShader.setFloat("material.specular", beanCanMat.specular);
	ourShader.setFloat("material.shininess", beanCanMat.shininess);
	beanSidesMesh.draw(glm::translate(model, glm::vec3(1.5f, 1.17f, 0.75f)) * beanRotation, ourShader, gBeanCanSides);
	beanTopMesh.draw(glm::translate(model, glm::vec3(1.5f, 1.17f, 0.75f)) * beanRotation, ourShader, gBeanCanTop);

	ourShader.setVec3("material.ambient", lolipopMat.ambient);
	ourShader.setVec3("material.diffuse", lolipopMat.diffuse);
	ourShader.setFloat("material.specular", lolipopMat.specular);
	ourShader.setFloat("material.shininess", lolipopMat.shininess);
	loliStickSidesMesh.draw(glm::translate(model, glm::vec3(1.25f, 1.33f, 0.5f)) * loliRotation, ourShader, gLoliStick);
	loliStickTopMesh.draw(glm::translate(model, glm::vec3(1.25f, 1.33f, 0.5f)) * loliRotation, ourShader, gLoliStick);

	lolipopMesh1.draw(glm::translate(model, glm::vec3(1.4f, 1.33f, 0.58f)) * loliRotation, ourShader, gLoliProper);
	lolipopMesh2.draw(glm::translate(model, glm::vec3(1.4f, 1.33f, 0.58f)) * loliRotation, ourShader, gLoliProper);

	ourShader.setVec3("material.ambient", pumpkinMat.ambient);
	ourShader.setVec3("material.diffuse", pumpkinMat.diffuse);
	ourShader.setFloat("material.specular", pumpkinMat.specular);
	ourShader.setFloat("material.shininess", pumpkinMat.shininess);
	pumpkinFace.draw(glm::translate(model, glm::vec3(0.5f, -0.22f, 1.0f)), ourShader, gPumpkinFace);
	pumpkinSides.draw(glm::translate(model, glm::vec3(0.5f, -0.22f, 1.0f)), ourShader, gPumpkinSides);

	ourShader.setVec3("material.ambient", lightMat.ambient);
	ourShader.setVec3("material.diffuse", lightMat.diffuse);
	ourShader.setFloat("material.specular", lightMat.specular);
	ourShader.setFloat("material.shininess", lightMat.shininess);
	lightBox.draw(glm::translate(model, lightPos[0]), ourShader, gLoliStick);
	lightBox.draw(glm::translate(model, lightPos[1]), ourShader, gLoliStick);
	lightBox.draw(glm::translate(model, lightPos[2]), ourShader, gLoliStick);
	lightBox.draw(glm::translate(model, lightPos[3]), ourShader, gLoliStick);

	glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

//Loads a texture from an image file
void loadTexture(const char* filename, GLuint& texture, bool flip) {
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width, height, nrChannels;
	stbi_set_flip_vertically_on_load(flip); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char* data = stbi_load(filename, &width, &height, &nrChannels, 0);
	if (data)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);
}

//Sets up all verticies for cube objects
void setupVertices() {
	
	boxSideMesh.vertices = {
		//Right Side
		glm::vec3(0.5f, 0.0f,  0.25f),
		glm::vec3(0.5f, 0.0f, -0.25f),
		glm::vec3(0.5f, 1.5f, -0.25f),
		glm::vec3(0.5f, 0.0f,  0.25f),
		glm::vec3(0.5f, 1.5f,  0.25f),
		glm::vec3(0.5f, 1.5f, -0.25f),

		//Left Side
		glm::vec3(-0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 0.0f,  0.25f),
		glm::vec3(-0.5f, 1.5f,  0.25f),
		glm::vec3(-0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 1.5f, -0.25f),
		glm::vec3(-0.5f, 1.5f,  0.25f)

	};

	boxFrontBackMesh.vertices = {
		
		//Back Face
		glm::vec3(0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 1.5f, -0.25f),
		glm::vec3(0.5f, 0.0f, -0.25f),
		glm::vec3(0.5f, 1.5f, -0.25f),
		glm::vec3(-0.5f, 1.5f, -0.25f),

		//Front Face
		glm::vec3(-0.5f, 0.0f,  0.25f),
		glm::vec3(0.5f, 0.0f,  0.25f),
		glm::vec3(0.5f, 1.5f,  0.25f),
		glm::vec3(-0.5f, 0.0f,  0.25f),
		glm::vec3(-0.5f, 1.5f,  0.25f),
		glm::vec3(0.5f, 1.5f,  0.25f),

		//Bottom Side
		glm::vec3(0.5f, 0.0f,  0.25f),
		glm::vec3(0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 0.0f,  0.25f),
		glm::vec3(0.5f, 0.0f,  0.25f),

		//Top Side
		glm::vec3(0.5f, 1.5f,  0.25f),
		glm::vec3(0.5f, 1.5f, -0.25f),
		glm::vec3(-0.5f, 1.5f, -0.25f),
		glm::vec3(-0.5f, 1.5f, -0.25f),
		glm::vec3(-0.5f, 1.5f,  0.25f),
		glm::vec3(0.5f, 1.5f,  0.25f)
	};

	topMesh.vertices = {
		//Bottom Side
		glm::vec3(0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 0.0f,  0.25f),
		glm::vec3(0.5f, 0.0f,  0.25f),
		glm::vec3(-0.5f, 0.0f, -0.25f),
		glm::vec3(-0.5f, 0.0f,  0.25f),

		//Right Side
		glm::vec3(0.5f, 0.0f,   0.25f),
		glm::vec3(0.5f, 0.125f, 0.0f),
		glm::vec3(0.5f, 0.0f,  -0.25f),

		//Left Side
		glm::vec3(-0.5f, 0.0f,   0.25f),
		glm::vec3(-0.5f, 0.0f,  -0.25f),
		glm::vec3(-0.5f, 0.125f, 0.0f),

		//Back Face
		glm::vec3(0.5f, 0.0f,  -0.25f),
		glm::vec3(-0.5f, 0.0f,   -0.25f),
		glm::vec3(-0.5f, 0.125f, 0.0f),
		glm::vec3(-0.5f, 0.125f, 0.0f),
		glm::vec3(0.5f, 0.125f, 0.0f),
		glm::vec3(0.5f, 0.0f,	 -0.25f),

		//Front Face
		glm::vec3(-0.5f, 0.125f, 0.0f),
		glm::vec3(-0.5f, 0.0f,   0.25f),
		glm::vec3(0.5f, 0.0f,   0.25f),
		glm::vec3(0.5f, 0.0f,   0.25f),
		glm::vec3(0.5f, 0.125f, 0.0f),
		glm::vec3(-0.5f, 0.125f, 0.0f)
	};

	planeMesh.vertices = {
		//Right Side
		glm::vec3(2.5f, 0.0f,    2.5f),
		glm::vec3(2.5f, 0.0f,   -2.5f),
		glm::vec3(2.5f, 0.125f, -2.5f),
		glm::vec3(2.5f, 0.0f,    2.5f),
		glm::vec3(2.5f, 0.125f,  2.5f),
		glm::vec3(2.5f, 0.125f, -2.5f),

		//Back Face
		glm::vec3(2.5f, 0.0f,   -2.5f),
		glm::vec3(-2.5f, 0.0f,	  -2.5f),
		glm::vec3(-2.5f, 0.125f, -2.5f),
		glm::vec3(2.5f, 0.0f,	  -2.5f),
		glm::vec3(2.5f, 0.125f, -2.5f),
		glm::vec3(-2.5f, 0.125f, -2.5f),

		//Left Side 
		glm::vec3(-2.5f, 0.0f,   -2.5f),
		glm::vec3(-2.5f, 0.0f,	   2.5f),
		glm::vec3(-2.5f, 0.125f,  2.5f),
		glm::vec3(-2.5f, 0.0f,   -2.5f),
		glm::vec3(-2.5f, 0.125f, -2.5f),
		glm::vec3(-2.5f, 0.125f,  2.5f),

		//Front Face
		glm::vec3(-2.5f, 0.0f,   2.5f),
		glm::vec3(2.5f, 0.0f,   2.5f),
		glm::vec3(2.5f, 0.125f, 2.5f),
		glm::vec3(-2.5f, 0.0f,   2.5f),
		glm::vec3(-2.5f, 0.125f, 2.5f),
		glm::vec3(2.5f, 0.125f, 2.5f),

		//Bottom Face
		glm::vec3(2.5f, 0.0f,  2.5f),
		glm::vec3(2.5f, 0.0f, -2.5f),
		glm::vec3(-2.5f, 0.0f, -2.5f),
		glm::vec3(-2.5f, 0.0f, -2.5f),
		glm::vec3(-2.5f, 0.0f,  2.5f),
		glm::vec3(2.5f, 0.0f,  2.5f),

		//Top Face
		glm::vec3(2.5f, 0.125f,  2.5f),
		glm::vec3(2.5f, 0.125f, -2.5f),
		glm::vec3(-2.5f, 0.125f, -2.5f),
		glm::vec3(-2.5f, 0.125f, -2.5f),
		glm::vec3(-2.5f, 0.125f,  2.5f),
		glm::vec3(2.5f, 0.125f,  2.5f)
	};

	pumpkinFace.vertices = {
		glm::vec3(-0.25f, 0.0f,  0.25f),
		glm::vec3(0.25f, 0.0f,  0.25f),
		glm::vec3(0.25f, 0.5f,  0.25f),
		glm::vec3(-0.25f, 0.0f,  0.25f),
		glm::vec3(-0.25f, 0.5f,  0.25f),
		glm::vec3(0.25f, 0.5f,  0.25f)
	};

	pumpkinSides.vertices = {
		//Back Face
		glm::vec3(0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.5f, -0.25f),
		glm::vec3(0.25f, 0.0f, -0.25f),
		glm::vec3(0.25f, 0.5f, -0.25f),
		glm::vec3(-0.25f, 0.5f, -0.25f),

		//Right Side
		glm::vec3(0.25f, 0.0f,  0.25f),
		glm::vec3(0.25f, 0.0f, -0.25f),
		glm::vec3(0.25f, 0.5f, -0.25f),
		glm::vec3(0.25f, 0.0f,  0.25f),
		glm::vec3(0.25f, 0.5f,  0.25f),
		glm::vec3(0.25f, 0.5f, -0.25f),

		//Left Side
		glm::vec3(-0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.0f,  0.25f),
		glm::vec3(-0.25f, 0.5f,  0.25f),
		glm::vec3(-0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.5f, -0.25f),
		glm::vec3(-0.25f, 0.5f,  0.25f),

		//Bottom Side
		glm::vec3(0.25f, 0.0f,  0.25f),
		glm::vec3(0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.0f,  0.25f),
		glm::vec3(0.25f, 0.0f,  0.25f),

		//Top Side
		glm::vec3(0.25f, 0.5f,  0.25f),
		glm::vec3(0.25f, 0.5f, -0.25f),
		glm::vec3(-0.25f, 0.5f, -0.25f),
		glm::vec3(-0.25f, 0.5f, -0.25f),
		glm::vec3(-0.25f, 0.5f,  0.25f),
		glm::vec3(0.25f, 0.5f,  0.25f)
	};
	
	lightBox.vertices = {
		//Right Side
		glm::vec3(0.25f, 0.0f,    0.25f),
		glm::vec3(0.25f, 0.0f,   -0.25f),
		glm::vec3(0.25f, 0.25f, -0.25f),
		glm::vec3(0.25f, 0.0f,    0.25f),
		glm::vec3(0.25f, 0.25f,  0.25f),
		glm::vec3(0.25f, 0.25f, -0.25f),

		//Back Face
		glm::vec3(0.25f, 0.0f,   -0.25f),
		glm::vec3(-0.25f, 0.0f,	  -0.25f),
		glm::vec3(-0.25f, 0.25f, -0.25f),
		glm::vec3(0.25f, 0.0f,	  -0.25f),
		glm::vec3(0.25f, 0.25f, -0.25f),
		glm::vec3(-0.25f, 0.25f, -0.25f),

		//Left Side 
		glm::vec3(-0.25f, 0.0f,   -0.25f),
		glm::vec3(-0.25f, 0.0f,	   0.25f),
		glm::vec3(-0.25f, 0.25f,  0.25f),
		glm::vec3(-0.25f, 0.0f,   -0.25f),
		glm::vec3(-0.25f, 0.25f, -0.25f),
		glm::vec3(-0.25f, 0.25f,  0.25f),

		//Front Face
		glm::vec3(-0.25f, 0.0f,   0.25f),
		glm::vec3(0.25f, 0.0f,   0.25f),
		glm::vec3(0.25f, 0.25f, 0.25f),
		glm::vec3(-0.25f, 0.0f,   0.25f),
		glm::vec3(-0.25f, 0.25f, 0.25f),
		glm::vec3(0.25f, 0.25f, 0.25f),

		//Bottom Face
		glm::vec3(0.25f, 0.0f,  0.25f),
		glm::vec3(0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.0f, -0.25f),
		glm::vec3(-0.25f, 0.0f,  0.25f),
		glm::vec3(0.25f, 0.0f,  0.25f),

		//Top Face
		glm::vec3(0.25f,0.25f,  0.25f),
		glm::vec3(0.25f, 0.25f, -0.25f),
		glm::vec3(-0.25f, 0.25f, -0.25f),
		glm::vec3(-0.25f, 0.25f, -0.25f),
		glm::vec3(-0.25f, 0.25f,  0.25f),
		glm::vec3(0.25f, 0.25f,  0.25f)
	};

}

// where I input the texture coords for all cube objects
void setupTextCoords() {
	
	boxSideMesh.texcoords = {
		//top = 0 in y bottom = 1 in y
		//right side
		//front = 0 in x back = 1 in x 
		glm::vec2(0.0f,1.0f), //front bottom
		glm::vec2(1.0f,1.0f), //back bottom
		glm::vec2(1.0f,0.0f), //back top
		glm::vec2(0.0f,1.0f), //front bottom
		glm::vec2(0.0f,0.0f), //front top
		glm::vec2(1.0f,0.0f), //back top

		//Left Side
		//back = 0 front = 1
		glm::vec2(0.0f,1.0f), //back bottom
		glm::vec2(1.0f,1.0f), //front bottom
		glm::vec2(1.0f,0.0f), //front top
		glm::vec2(0.0f,1.0f), //back bottom
		glm::vec2(0.0f,0.0f), //back top
		glm::vec2(1.0f,0.0f), //front top

	};

	boxFrontBackMesh.texcoords = {
		
		//back side
		//right = 0 left = 1 
		glm::vec2(0.0f,1.0f), //right bottom
		glm::vec2(1.0f,1.0f), // left bottom
		glm::vec2(1.0f,0.0f), // left top
		glm::vec2(0.0f,1.0f), // right bottom
		glm::vec2(0.0f,0.0f), // right top
		glm::vec2(1.0f,0.0f), // left top

		//Front Side
		//left = 0 right = 1
		glm::vec2(0.0f,1.0f), //left bottom
		glm::vec2(1.0f,1.0f), //right bottom
		glm::vec2(1.0f,0.0f), //right top
		glm::vec2(0.0f,1.0f), //left bottom
		glm::vec2(0.0f,0.0f), //left top
		glm::vec2(1.0f,0.0f), //right top

		//Bottom Side
		//Front = 0 Back = 1 Left = 0 Right = 1
		glm::vec2(1.0f,0.0f), //front right 
		glm::vec2(1.0f,1.0f), //back right
		glm::vec2(0.0f,1.0f), //back left
		glm::vec2(0.0f,1.0f), //back left 
		glm::vec2(0.0f,0.0f), //front left
		glm::vec2(1.0f,0.0f), //front right

		//Top Side
		//Back = 0 Front = 1 Left = 0 Right = 1
		glm::vec2(1.0f,1.0f), //front right
		glm::vec2(1.0f,0.0f), //back right
		glm::vec2(0.0f,0.0f), //back left
		glm::vec2(0.0f,0.0f), //back left
		glm::vec2(0.0f,1.0f), //front left
		glm::vec2(1.0f,1.0f), //front right
	};

	topMesh.texcoords = {
		//Bottom Side
		//front = 0 back = 1 left = 0 right = 1
		glm::vec2(1.0f,1.0f), //right back
		glm::vec2(0.0f,1.0f), //left back
		glm::vec2(0.0f,0.0f), //left front
		glm::vec2(1.0f,0.0f), //right front
		glm::vec2(0.0f,1.0f), //left back
		glm::vec2(0.0f,0.0f), //left front

		//Right Side
		glm::vec2(0.0f,1.0f), //front right
		glm::vec2(0.5f,0.0f), //right top
		glm::vec2(1.0f,1.0f), //back right

		//Left Side
		glm::vec2(1.0f,1.0f), //front left
		glm::vec2(0.0f,1.0f), //back left
		glm::vec2(0.5f,0.0f), //top left

		//Back Face
		//right = 0 left = 1 top = 0 bottom = 1
		glm::vec2(0.0f,1.0f), //right back
		glm::vec2(1.0f,1.0f), //left back
		glm::vec2(1.0f,0.0f), //left top
		glm::vec2(1.0f,0.0f), //left top
		glm::vec2(0.0f,0.0f), //right top
		glm::vec2(0.0f,1.0f), //right back

		//Front Face
		//left = 0 right = 1 top = 0 bottom = 1
		glm::vec2(0.0f,0.0f), //left top
		glm::vec2(0.0f,1.0f), //left front
		glm::vec2(1.0f,1.0f), //right front
		glm::vec2(1.0f,1.0f), //right front
		glm::vec2(1.0f,0.0f), //right top
		glm::vec2(0.0f,0.0f), //left top
	};

	planeMesh.texcoords = {
		//Right
		//front = 0 in x back = 1 in x 
		glm::vec2(0.0f,1.0f), // front bottom
		glm::vec2(1.0f,1.0f), //back bottom
		glm::vec2(1.0f,0.0f), //back top
		glm::vec2(0.0f,1.0f), //front bottom
		glm::vec2(0.0f,0.0f), //front top
		glm::vec2(1.0f,0.0f), //back top

		//Back
		//right = 0 left = 1
		glm::vec2(0.0f,1.0f), //right bottom
		glm::vec2(1.0f,1.0f), //left bottom
		glm::vec2(1.0f,0.0f), //left top
		glm::vec2(0.0f,1.0f), //right bottom
		glm::vec2(0.0f,0.0f), //right top
		glm::vec2(1.0f,0.0f), //left top

		//Left
		//back = 0 front = 1
		glm::vec2(0.0f,1.0f), //back bottom
		glm::vec2(1.0f,1.0f), //front bottom
		glm::vec2(1.0f,0.0f), //front top
		glm::vec2(0.0f,1.0f), //back bottom
		glm::vec2(0.0f,0.0f), //back top
		glm::vec2(1.0f,0.0f), //front top

		//Front
		//left = 0 right = 1
		glm::vec2(0.0f,1.0f), //left bottom
		glm::vec2(1.0f,1.0f), //right bottom
		glm::vec2(1.0f,0.0f), //right top
		glm::vec2(0.0f,1.0f), //left bottom
		glm::vec2(0.0f,0.0f), //left top
		glm::vec2(1.0f,0.0f), //right top

		//Bottom 
		//Front = 0 Back = 1 Left = 0 Right = 1
		glm::vec2(1.0f,0.0f), //right front
		glm::vec2(1.0f,1.0f), //right back
		glm::vec2(0.0f,1.0f), //left back
		glm::vec2(0.0f,1.0f), //left back
		glm::vec2(0.0f,0.0f), //left front
		glm::vec2(1.0f,0.0f), //right front

		//Top
		//Back = 0 Front = 1 Left = 0 Right = 1
		glm::vec2(1.0f,1.0f), //right front
		glm::vec2(1.0f,0.0f), //right back
		glm::vec2(0.0f,0.0f), //left back
		glm::vec2(0.0f,0.0f), //left back 
		glm::vec2(0.0f,1.0f), //left front
		glm::vec2(1.0f,1.0f), //right front
	};

	pumpkinFace.texcoords = {
		glm::vec2(0.0f,1.0f), //left bottom
		glm::vec2(1.0f,1.0f), //right bottom
		glm::vec2(1.0f,0.0f), //right top
		glm::vec2(0.0f,1.0f), //left bottom
		glm::vec2(0.0f,0.0f), //left top
		glm::vec2(1.0f,0.0f) //right top
	};

	pumpkinSides.texcoords = {
		//back side
		//right = 0 left = 1 
		glm::vec2(0.0f,1.0f), //right bottom
		glm::vec2(1.0f,1.0f), // left bottom
		glm::vec2(1.0f,0.0f), // left top
		glm::vec2(0.0f,1.0f), // right bottom
		glm::vec2(0.0f,0.0f), // right top
		glm::vec2(1.0f,0.0f), // left top

		//right side
		//front = 0 in x back = 1 in x 
		glm::vec2(0.0f,1.0f), //front bottom
		glm::vec2(1.0f,1.0f), //back bottom
		glm::vec2(1.0f,0.0f), //back top
		glm::vec2(0.0f,1.0f), //front bottom
		glm::vec2(0.0f,0.0f), //front top
		glm::vec2(1.0f,0.0f), //back top

		//Left Side
		//back = 0 front = 1
		glm::vec2(0.0f,1.0f), //back bottom
		glm::vec2(1.0f,1.0f), //front bottom
		glm::vec2(1.0f,0.0f), //front top
		glm::vec2(0.0f,1.0f), //back bottom
		glm::vec2(0.0f,0.0f), //back top
		glm::vec2(1.0f,0.0f), //front top

		//Bottom Side
		//Front = 0 Back = 1 Left = 0 Right = 1
		glm::vec2(1.0f,0.0f), //front right 
		glm::vec2(1.0f,1.0f), //back right
		glm::vec2(0.0f,1.0f), //back left
		glm::vec2(0.0f,1.0f), //back left 
		glm::vec2(0.0f,0.0f), //front left
		glm::vec2(1.0f,0.0f), //front right

		//Top Side
		//Back = 0 Front = 1 Left = 0 Right = 1
		glm::vec2(1.0f,1.0f), //front right
		glm::vec2(1.0f,0.0f), //back right
		glm::vec2(0.0f,0.0f), //back left
		glm::vec2(0.0f,0.0f), //back left
		glm::vec2(0.0f,1.0f), //front left
		glm::vec2(1.0f,1.0f), //front right
	};

	lightBox.texcoords = {
		//Right
		//front = 0 in x back = 1 in x 
		glm::vec2(0.0f,1.0f), // front bottom
		glm::vec2(1.0f,1.0f), //back bottom
		glm::vec2(1.0f,0.0f), //back top
		glm::vec2(0.0f,1.0f), //front bottom
		glm::vec2(0.0f,0.0f), //front top
		glm::vec2(1.0f,0.0f), //back top

		//Back
		//right = 0 left = 1
		glm::vec2(0.0f,1.0f), //right bottom
		glm::vec2(1.0f,1.0f), //left bottom
		glm::vec2(1.0f,0.0f), //left top
		glm::vec2(0.0f,1.0f), //right bottom
		glm::vec2(0.0f,0.0f), //right top
		glm::vec2(1.0f,0.0f), //left top

		//Left
		//back = 0 front = 1
		glm::vec2(0.0f,1.0f), //back bottom
		glm::vec2(1.0f,1.0f), //front bottom
		glm::vec2(1.0f,0.0f), //front top
		glm::vec2(0.0f,1.0f), //back bottom
		glm::vec2(0.0f,0.0f), //back top
		glm::vec2(1.0f,0.0f), //front top

		//Front
		//left = 0 right = 1
		glm::vec2(0.0f,1.0f), //left bottom
		glm::vec2(1.0f,1.0f), //right bottom
		glm::vec2(1.0f,0.0f), //right top
		glm::vec2(0.0f,1.0f), //left bottom
		glm::vec2(0.0f,0.0f), //left top
		glm::vec2(1.0f,0.0f), //right top

		//Bottom 
		//Front = 0 Back = 1 Left = 0 Right = 1
		glm::vec2(1.0f,0.0f), //right front
		glm::vec2(1.0f,1.0f), //right back
		glm::vec2(0.0f,1.0f), //left back
		glm::vec2(0.0f,1.0f), //left back
		glm::vec2(0.0f,0.0f), //left front
		glm::vec2(1.0f,0.0f), //right front

		//Top
		//Back = 0 Front = 1 Left = 0 Right = 1
		glm::vec2(1.0f,1.0f), //right front
		glm::vec2(1.0f,0.0f), //right back
		glm::vec2(0.0f,0.0f), //left back
		glm::vec2(0.0f,0.0f), //left back 
		glm::vec2(0.0f,1.0f), //left front
		glm::vec2(1.0f,1.0f), //right front
	};
}

//Setup materials for each object
void setupMaterials() {
	boxMat.ambient = glm::vec3(0.2f, 0.2f, 0.2f);
	boxMat.diffuse = glm::vec3(0.5f, 0.5f, 0.5f);
	boxMat.shininess = 16.0f;
	boxMat.specular = 0.1f;

	counterMat.ambient = glm::vec3(0.1f, 0.1f, 0.1f);
	counterMat.diffuse = glm::vec3(0.5f, 0.5f, 0.5f);
	counterMat.specular = 1.5f;
	counterMat.shininess = 32.0f;

	beanCanMat.ambient = glm::vec3(0.1f, 0.1f, 0.1f);
	beanCanMat.diffuse = glm::vec3(0.5f, 0.5f, 0.5f);
	beanCanMat.specular = 1.5f;
	beanCanMat.shininess = 32.0f;

	lolipopMat.ambient = glm::vec3(0.1f, 0.1f, 0.1f);
	lolipopMat.diffuse = glm::vec3(0.5f, 0.5f, 0.5f);
	lolipopMat.specular = 3.0f;
	lolipopMat.shininess = 32.0f;

	pumpkinMat.ambient = glm::vec3(0.2f, 0.2f, 0.2f);
	pumpkinMat.diffuse = glm::vec3(0.5f, 0.5f, 0.5f);
	pumpkinMat.specular = 0.1f;
	pumpkinMat.shininess = 16.0f;

	lightMat.ambient = glm::vec3(0.2f, 0.2f, 0.2f);
	lightMat.diffuse = glm::vec3(0.5f, 0.5f, 0.5f);
	lightMat.specular = 0.1f;
	lightMat.shininess = 16.0f;
}

//Any cylinders are created here
void setupCylinders() {
	Cylinder beans;
	beans.setSize(1.4f, 0.5f);
	beans.buildCylinder();
	beanSidesMesh.vertices = beans.getVerticesSides();
	beanSidesMesh.texcoords = beans.getTexCoordsSides();
	beanSidesMesh.normals = beans.getNormsSides();
	beanTopMesh.vertices = beans.getVerticiesBase();
	beanTopMesh.texcoords = beans.getTexCoordsBase();
	beanTopMesh.normals = beans.getNormsBase();

	Cylinder lolipopStick;
	lolipopStick.setSize(1.0f, 0.025f);
	lolipopStick.buildCylinder();
	loliStickSidesMesh.vertices = lolipopStick.getVerticesSides();
	loliStickSidesMesh.texcoords = lolipopStick.getTexCoordsSides();
	loliStickSidesMesh.normals = lolipopStick.getNormsSides();
	loliStickTopMesh.vertices = lolipopStick.getVerticiesBase();
	loliStickTopMesh.texcoords = lolipopStick.getTexCoordsBase();
	loliStickTopMesh.normals = lolipopStick.getNormsBase();

	Cylinder lolipopProper;
	lolipopProper.setSize(0.25f, 0.15f);
	lolipopProper.buildCylinder();
	lolipopMesh1.vertices = lolipopProper.getVerticesSides();
	lolipopMesh1.texcoords = lolipopProper.getTexCoordsSides();
	lolipopMesh1.normals = lolipopProper.getNormsSides();
	lolipopMesh2.vertices = lolipopProper.getVerticiesBase();
	lolipopMesh2.texcoords = lolipopProper.getTexCoordsBase();
	lolipopMesh2.normals = lolipopProper.getNormsBase();

}

// uploads all my meshes, creating VBOs and some normals
void uploadAll() {
	boxFrontBackMesh.upload(true);
	boxSideMesh.upload(true);
	topMesh.upload(true);
	planeMesh.upload(true);
	beanSidesMesh.upload(false);
	beanTopMesh.upload(false);
	loliStickSidesMesh.upload(false);
	loliStickTopMesh.upload(false);
	lolipopMesh1.upload(false);
	lolipopMesh2.upload(false);
	pumpkinFace.upload(true);
	pumpkinSides.upload(true);
	lightBox.upload(true);
}

//Cleans up all vbos and meshes
void cleanupAll() {
	boxFrontBackMesh.cleanUp();
	boxSideMesh.cleanUp();
	topMesh.cleanUp();
	planeMesh.cleanUp();
	beanSidesMesh.cleanUp();
	beanTopMesh.cleanUp();
	loliStickSidesMesh.cleanUp();
	loliStickTopMesh.cleanUp();
	lolipopMesh1.cleanUp();
	lolipopMesh2.cleanUp();
	pumpkinFace.cleanUp();
	pumpkinSides.cleanUp();
	lightBox.cleanUp();
}
